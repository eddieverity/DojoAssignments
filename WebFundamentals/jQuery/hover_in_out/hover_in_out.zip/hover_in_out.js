$(document).ready (function() {
  $(".tog").hover(function(){
    $('img',this).toggle();
  });
});
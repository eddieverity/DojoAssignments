$(document).ready (function() {
  $(".tog").click(function(){
    $('img',this).toggle();
  });
});
var new_word = "NEW!";
function lastFunc() {
  new_word = "old";
}
console.log(new_word);

// rearrangement

var new_word;
function lastFunc() {
  new_word = "old";
}
new_word="new!!"
console.log(new_word)
function multiplyByTen(arg) {
  return arg*10
}
multiplyByTen(5);
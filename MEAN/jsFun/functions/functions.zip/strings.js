function stringReturnOne(){
  return 'Hard-coded string1'
}
function stringReturnTwo(){
  return 'Hard-coded string2'
}
function runningLogger() {
  console.log('I am running!');
}
runningLogger();
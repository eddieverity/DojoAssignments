function caller(param){
  if (typeof(param)==function){
    param();
  }
}

    // def __init__(self, name, fuel_capacity, length):
    //     self.name = name
    //     self.fuel_capacity = fuel_capacity
    //     self.length = length
    //     self.current_speed = 0
    //     self.x_coord = 0
    //     self.y_coord = 0
    //     self.is_on = False
    //     self.mileage = 0

    function Car(name, fuel_capacity, length) {
        this.name = name;
        this.fuel_capacity = fuel_capacity;
        this.length = length;
        this.current_speed = 0;
        this.x_coord = 0;
        this.y_coord = 0;
        this.is_on = false;
        this.mileage = 0;

        this.startCar = function() {
            if (!this.is_on) {
                this.is_on = true;
            }
        };

        this.drive = function(miles) {
            if (this.is_on) {
                this.mileage = this.mileage + miles;
                console.log("Total Miles: ", this.mileage);
            } else {
                console.log("PLEASE TURN THE CAR ON!");
            }
        };
    }


    var camry = new Car("Toyota Camry", "16 gallons", 20);
    console.log(camry.name);
    camry.startCar();
    camry.drive(50);
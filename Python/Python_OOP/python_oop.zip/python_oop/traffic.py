class Car(object):
    def __init__(self, name, fuel_capacity, length):
        self.name = name
        self.fuel_capacity = fuel_capacity
        self.length = length
        self.current_speed = 0
        self.x_coord = 0
        self.y_coord = 0
        self.is_on = False
        self.mileage = 0
    
    def start_car(self):
        if not self.is_on:
            self.is_on = True
    
    def drive(self, miles):
        if self.is_on:
            self.mileage = self.mileage + miles
            print "Total Miles:", self.mileage
        else:
            print "Please turn the car on with the appropriate method!"

class Road(object):
    def __init__(self, name, lanes, speed_limit, length):
        print "initializing the road", name
        self.name = name
        self.lanes = lanes
        self.speed_limit = speed_limit
        self.length = length
        self.cars = []
        self.condition = "under construction"
        self.potholes = 0

    def begin_construction(self):
        if self.condition != "under construction":
            self.condition = "under construction"
            self.lanes = 0
            self.speed_limit = 0

    def end_construction(self):
        if self.condition != "open road":
            self.condition = "open road"


    def assess_road(self):
        if self.potholes / self.length > 0.5:
            self.begin_construction()

    def add_car(self, car, index):
        if len(self.cars) < 30 and self.condition != "under construction":
            print "added car", index
            self.cars.append(car)
        else:
            print "no more cars allows, please queue up and wait to enter", self.name


camry = Car("Toyota Camry", "16 gallons", 20)
print camry.name
camry.start_car()
camry.drive(50)
# chicago_ave = Road('Chicago Ave', 2, 30, 5)
# chicago_ave.end_construction()
# print chicago_ave.condition
# for number in range(50):
#     name = "car " + str(number)
#     car = Car(name, "20 gallons", 20)
#     chicago_ave.add_car(car, number)



# class TrafficLight(object):
#     pass


a = [1,2,5,10,255,3]
sum = 0
for i in a:
  sum +=i
avg = sum/len(a)
print avg
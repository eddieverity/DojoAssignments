#use for loop to print 5-1000000 by mult of 5
i = 5
while i<1000000:
  print i
  i=i+5
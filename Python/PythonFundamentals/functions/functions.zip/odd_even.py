def odd_even():
  for i in range(1,2001):
    if i%2==0:
      print "The number is " + str(i) + ".  This is an even number."
    else:
      print "The number is " + str(i) + ".  This is an odd number."
odd_even()
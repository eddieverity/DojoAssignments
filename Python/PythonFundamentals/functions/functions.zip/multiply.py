def multiply(arr,mult):
  z = []
  for i in arr:
    z.append(i*mult)
  return z
b = multiply([1,9,3,44,5],5)
print b